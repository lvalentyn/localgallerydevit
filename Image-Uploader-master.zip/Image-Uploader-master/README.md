# Image-Uploader
In this repository i had created image uploader using JavaScript

Upload images in the ./upload folder and just run application.

run application and just select ./upload folder to upload images on the browser.


**************************************************************************************************************************************

                                                                Thank You
                                                                
                                                                
***************************************************************************************************************************************
